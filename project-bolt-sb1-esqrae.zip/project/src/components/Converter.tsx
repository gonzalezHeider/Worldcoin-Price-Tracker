import React, { useState, useEffect } from 'react';
import { getCOPRate } from '../services/api';

interface ConverterProps {
  wldPrice: number;
}

export const Converter: React.FC<ConverterProps> = ({ wldPrice }) => {
  const [wldAmount, setWldAmount] = useState<string>('');
  const [copRate, setCopRate] = useState<number>(0);

  useEffect(() => {
    const fetchRate = async () => {
      const { rate } = await getCOPRate();
      setCopRate(rate);
    };
    fetchRate();
  }, []);

  const calculateCOP = () => {
    const amount = parseFloat(wldAmount) || 0;
    const usdValue = amount * wldPrice;
    return (usdValue * copRate).toLocaleString('es-CO');
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-2">
          Cantidad de WLD
        </label>
        <input
          type="number"
          value={wldAmount}
          onChange={(e) => setWldAmount(e.target.value)}
          className="w-full bg-white dark:bg-gray-800 text-black dark:text-white rounded-md p-2 border border-gray-300 dark:border-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          placeholder="0.00"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-2">
          Valor en COP
        </label>
        <div className="bg-white dark:bg-gray-800 text-black dark:text-white rounded-md p-2 border border-gray-300 dark:border-gray-700">
          $ {calculateCOP()} COP
        </div>
      </div>
    </div>
  );
};