import React from 'react';
import { User } from 'lucide-react';

export const UserProfile: React.FC = () => {
  return (
    <div className="flex items-center gap-4 text-white">
      <div className="flex items-center gap-2">
        <User className="text-blue-500" />
        <div>
          <p className="font-semibold">Haider Ing</p>
          <p className="text-sm text-gray-400">WLD Balance: 99.00</p>
        </div>
      </div>
    </div>
  );
};