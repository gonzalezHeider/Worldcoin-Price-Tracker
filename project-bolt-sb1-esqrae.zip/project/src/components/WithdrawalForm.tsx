import React, { useState } from 'react';
import { DollarSign, ArrowRight } from 'lucide-react';

interface WithdrawalFormProps {
  wldPrice: number;
}

export const WithdrawalForm: React.FC<WithdrawalFormProps> = ({ wldPrice }) => {
  const [wldAmount, setWldAmount] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setWldAmount('');
      setAccountNumber('');
    }, 1500);
  };

  const calculateCOP = () => {
    const amount = parseFloat(wldAmount) || 0;
    const usdValue = amount * wldPrice;
    return (usdValue * 3900).toLocaleString('es-CO'); // Using fixed COP rate for example
  };

  return (
    <div className="bg-gray-100 dark:bg-slate-800 p-6 rounded-lg mt-6 transition-colors duration-200">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <DollarSign className="text-blue-500" />
        Retiros
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">
            Cantidad de WLD a retirar
          </label>
          <input
            type="number"
            value={wldAmount}
            onChange={(e) => setWldAmount(e.target.value)}
            className="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-md p-3 border border-gray-300 dark:border-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors duration-200"
            placeholder="0.00"
            required
          />
          {wldAmount && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Valor aproximado: ${calculateCOP()} COP
            </p>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">
            Número de cuenta bancaria
          </label>
          <input
            type="text"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            className="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-md p-3 border border-gray-300 dark:border-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors duration-200"
            placeholder="Ingrese su número de cuenta"
            required
          />
        </div>
        <button
          type="submit"
          disabled={isSubmitting}
          className={`w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-md transition-all duration-200 flex items-center justify-center gap-2 ${
            isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
          }`}
        >
          {isSubmitting ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Procesando...
            </>
          ) : (
            <>
              Retirar
              <ArrowRight className="w-5 h-5" />
            </>
          )}
        </button>
      </form>
    </div>
  );
};