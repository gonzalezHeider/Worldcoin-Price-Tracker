import React, { useState } from 'react';
import { Eye, EyeOff, Copy, Check } from 'lucide-react';

export const WalletInfo: React.FC = () => {
  const [showWallet, setShowWallet] = useState(false);
  const [copied, setCopied] = useState(false);
  const walletNumber = "1234567890";

  const handleCopy = () => {
    navigator.clipboard.writeText(walletNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gray-100 dark:bg-slate-800 p-6 rounded-lg mt-6 transition-colors duration-200">
      <h3 className="text-lg font-semibold mb-4">Wallet Information</h3>
      <div className="flex items-center gap-4">
        <div className="flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-md px-4 py-2 font-mono transition-colors duration-200">
          {showWallet ? walletNumber : '••••••••••'}
        </div>
        <button
          onClick={() => setShowWallet(!showWallet)}
          className="p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded-md transition-colors"
          aria-label={showWallet ? 'Hide wallet number' : 'Show wallet number'}
        >
          {showWallet ? <EyeOff className="text-blue-500" /> : <Eye className="text-blue-500" />}
        </button>
        <button
          onClick={handleCopy}
          className="p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded-md transition-colors"
          aria-label="Copy wallet number"
        >
          {copied ? (
            <Check className="text-green-500" />
          ) : (
            <Copy className="text-blue-500" />
          )}
        </button>
      </div>
    </div>
  );
};