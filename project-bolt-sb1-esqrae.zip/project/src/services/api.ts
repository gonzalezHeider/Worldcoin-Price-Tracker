import axios from 'axios';

const api = axios.create({
  baseURL: 'https://api.binance.com/api/v3',
});

export const getWLDPrice = async () => {
  const response = await api.get('/ticker/price', {
    params: { symbol: 'WLDUSDT' },
  });
  return response.data;
};

export const getWLDKlines = async () => {
  const response = await api.get('/klines', {
    params: {
      symbol: 'WLDUSDT',
      interval: '1h',
      limit: 24,
    },
  });
  return response.data;
};

// Simulated COP rate - in a real app, you'd use a proper currency conversion API
export const getCOPRate = async () => {
  return { rate: 3900 }; // Example fixed rate USD to COP
};