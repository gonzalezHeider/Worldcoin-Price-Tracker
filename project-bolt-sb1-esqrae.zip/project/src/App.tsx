import React, { useEffect, useState } from 'react';
import { getWLDPrice, getWLDKlines } from './services/api';
import { PriceChart } from './components/PriceChart';
import { Converter } from './components/Converter';
import { UserProfile } from './components/UserProfile';
import { WalletInfo } from './components/WalletInfo';
import { WithdrawalForm } from './components/WithdrawalForm';
import { ThemeToggle } from './components/ThemeToggle';
import { LineChart, Wallet } from 'lucide-react';

function App() {
  const [price, setPrice] = useState<number>(0);
  const [chartData, setChartData] = useState<Array<{ time: string; price: number }>>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const priceData = await getWLDPrice();
        setPrice(parseFloat(priceData.price));

        const klines = await getWLDKlines();
        const formattedData = klines.map((kline: any[]) => ({
          time: new Date(kline[0]).toLocaleTimeString(),
          price: parseFloat(kline[4]),
        }));
        setChartData(formattedData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900 text-slate-900 dark:text-white transition-colors duration-200">
      <header className="bg-gray-100 dark:bg-slate-800 p-4 border-b border-gray-200 dark:border-slate-700">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <LineChart className="text-blue-500" />
            Worldcoin Tracker
          </h1>
          <UserProfile />
        </div>
      </header>

      <main className="container mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-gray-100 dark:bg-slate-800 p-6 rounded-lg shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold">WLD/USDT</h2>
                  <p className="text-3xl font-bold text-blue-500">
                    ${price.toFixed(4)}
                  </p>
                </div>
              </div>
              <PriceChart data={chartData} />
              <WalletInfo />
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-4 space-y-6">
              <div className="bg-gray-100 dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                <div className="flex items-center gap-2 mb-4">
                  <Wallet className="text-blue-500" />
                  <h2 className="text-xl font-bold">Conversor</h2>
                </div>
                <Converter wldPrice={price} />
              </div>
              <WithdrawalForm wldPrice={price} />
            </div>
          </div>
        </div>
      </main>

      <ThemeToggle />
    </div>
  );
}

export default App;