export interface PriceData {
  price: string;
  timestamp: number;
}

export interface ConversionRate {
  rate: number;
  lastUpdated: string;
}